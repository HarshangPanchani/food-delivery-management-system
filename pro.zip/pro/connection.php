<?php
 $con = mysqli_connect("localhost","root","","db_nbc (1))") or die("connection not successful");
 ?>
 
